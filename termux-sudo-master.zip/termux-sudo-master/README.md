# termux-sudo
A bash script that provides sudo for Termux  
Termux is a terminal emulator and Linux environment for Android

**Notice**

Due to the fact that Microsoft is purchasing GitHub, I have decided to move termux-sudo to GitLab.  
https://gitlab.com/st42/termux-sudo  
I'm sorry for any inconvenience this may cause, but I'm not going to be around when Microsoft turns GitHub into a disaster.  
It's better to to jump ship while the lifeboats are still available.
